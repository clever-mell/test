import Cocoa

var greeting = "Hello, playground"
greeting = "Rebbeca"
greeting = "Kelee"

let character = "Taylor"

var playName = "Roy"
print(playName)
playName = "Dani"
print(playName)

playName = "Sam"
print(playName)

let movie = """
A day in
life of
an Apple engineer
"""
print(playName.count)
print(greeting.uppercased())

let score = 10
let Bignumber = 1000_000

let qoshish = score + 2
let ayrish = score - 5
let kopaytiruv = score * score
let boluv = score / 5


let number = 7
print(number.isMultiple(of: 7))

let number1 = 0.1 + 0.2
print(number1)


//  How to store Decimal numbers
let a = 5
let b = 4.1
let c = a + Int(b) // Double(a) + b




